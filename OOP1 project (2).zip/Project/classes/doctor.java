
package classes;
import interfaces.*;
import java.util.Scanner;
public class doctor implements Hospital
{
    public String did, dname, specilist, appoint, doc_qual;
   public int droom;
  public  void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID:");
        did = input.nextLine();
        System.out.print("Name:");
        dname = input.nextLine();
        System.out.print("Specilization:");
        specilist = input.nextLine();
        System.out.print("Work time:");
        appoint = input.nextLine();
        System.out.print("Qualification:");
        doc_qual = input.nextLine();
        System.out.print("Room no.:");
        droom = input.nextInt();
    }
    public void doctor_info()
    {
        System.out.println(did + "\t" + dname + " \t" + specilist + "     \t" + appoint + "      \t" +  "\t" + doc_qual);
    }
}

