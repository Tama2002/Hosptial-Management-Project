package classes;
import interfaces.*;
import java.util.Scanner;
public class patient
{
 public   String pid, pname, disease, gender;
 public   int age;
    public void new_patient()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("ID:");
        pid = input.nextLine();
        System.out.print("Name:");
        pname = input.nextLine();
        System.out.print("Disease:");
        disease = input.nextLine();
        System.out.print("gender:");
        gender = input.nextLine();
       
        System.out.print("Age:");
        age = input.nextInt();
    }
   public void patient_info()
    {
        System.out.println(pid + "\t" + pname + " \t" + disease + "     \t" + gender + "      \t" + age);
    }
}