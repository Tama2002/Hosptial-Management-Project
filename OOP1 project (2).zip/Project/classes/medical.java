package classes;
import interfaces.*;
import java.util.Scanner;

public class medical implements Utilities
{
   public String med_name, med_comp, exp_date;
   public int med_cost, count;
   public void new_medi()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Name:");
        med_name = input.nextLine();
        System.out.print("Comp:");
        med_comp = input.nextLine();
        System.out.print("Exp_date:");
        exp_date = input.nextLine();
        System.out.print("Cost:");
        med_cost = input.nextInt();
        System.out.print("No of unit:");
        count = input.nextInt();
    }
}
